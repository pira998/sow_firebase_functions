const functions = require("firebase-functions");
const admin = require("firebase-admin")
const stripe = require('stripe')('sk_test_51JdT8ABTMX0Txwgt5sk68HsKyhzIIf1bkV41cuf8Sx9UU6LtkVbBySRsXx0XyapRPfhDStIKQzJ4BtvGNUj8LQL400nOEVSR2V');

admin.initializeApp()
const db = admin.firestore()


exports.users = functions.https.onRequest(async(request,response) =>{
  const snapshot = await db.collection("users").get()
  const users = snapshot.empty?
   []
   : snapshot.docs.map(doc=>Object.assign(doc.data(),{id:doc.id}))
  response.send(users)
})

exports.vendors = functions.https.onRequest(async(request,response) =>{
  const snapshot = await db.collection("vendors").get()
  const users = snapshot.empty?
   []
   : snapshot.docs.map(doc=>Object.assign(doc.data(),{id:doc.id}))
  response.send(users)
})

exports.products = functions.https.onRequest(async(request,response) =>{
  const snapshot = await db.collection("products").get()
  const users = snapshot.empty?
   []
   : snapshot.docs.map(doc=>Object.assign(doc.data(),{id:doc.id}))
  response.send(users)
})

exports.catagories = functions.https.onRequest(async(request,response) =>{
  const snapshot = await db.collection("categories").get()
  const users = snapshot.empty?
   []
   : snapshot.docs.map(doc=>Object.assign(doc.data(),{id:doc.id}))
  response.send(users)
})


exports.completePaymentWithStripe = functions.https.onRequest(async(req,res)=>{
  try{
  const charge = await stripe.charges.create({
    amount:req.body.amount,
    currency:req.body.currency,
    // source:req.body.token
  })
  res.send(charge)
  } catch(error){
    res.send(error)
  }
})

exports.updateUserMobile = functions.https.onRequest(async(request,response)=>{
  const body = JSON.parse(request.body)
  const mobile = body.mobile
  const currentUserID = body.id
  const ref = await db.collection('users').doc(currentUserID).update({mobile})
  response.send(mobile)
})